﻿namespace window {
    partial class AdminUser {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.usernameT = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.userCard = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.idCard = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.regDate = new System.Windows.Forms.TextBox();
            this.typeName = new System.Windows.Forms.ComboBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.newPassword = new System.Windows.Forms.TextBox();
            this.newUsername = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.dept = new System.Windows.Forms.TextBox();
            this.sex = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(36, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "用户名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(60, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(12, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "读者姓名";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(60, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "磁卡";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(12, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "读者类型";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(36, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "身份证";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(60, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "性别";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(60, 341);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "电话";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(12, 420);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "注册时间";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(60, 301);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "年龄";
            // 
            // usernameT
            // 
            this.usernameT.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.usernameT.Location = new System.Drawing.Point(124, 6);
            this.usernameT.Name = "usernameT";
            this.usernameT.ReadOnly = true;
            this.usernameT.Size = new System.Drawing.Size(250, 34);
            this.usernameT.TabIndex = 11;
            this.usernameT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // password
            // 
            this.password.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.password.Location = new System.Drawing.Point(124, 45);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(250, 34);
            this.password.TabIndex = 12;
            this.password.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // userCard
            // 
            this.userCard.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userCard.Location = new System.Drawing.Point(124, 85);
            this.userCard.Name = "userCard";
            this.userCard.ReadOnly = true;
            this.userCard.Size = new System.Drawing.Size(250, 34);
            this.userCard.TabIndex = 13;
            this.userCard.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name.Location = new System.Drawing.Point(124, 169);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(250, 34);
            this.name.TabIndex = 14;
            this.name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // idCard
            // 
            this.idCard.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.idCard.Location = new System.Drawing.Point(124, 213);
            this.idCard.Name = "idCard";
            this.idCard.ReadOnly = true;
            this.idCard.Size = new System.Drawing.Size(250, 34);
            this.idCard.TabIndex = 15;
            this.idCard.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // age
            // 
            this.age.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.age.Location = new System.Drawing.Point(124, 298);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(250, 34);
            this.age.TabIndex = 17;
            this.age.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // phone
            // 
            this.phone.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.phone.Location = new System.Drawing.Point(124, 338);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(250, 34);
            this.phone.TabIndex = 18;
            this.phone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // regDate
            // 
            this.regDate.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.regDate.Location = new System.Drawing.Point(124, 417);
            this.regDate.Name = "regDate";
            this.regDate.ReadOnly = true;
            this.regDate.Size = new System.Drawing.Size(250, 34);
            this.regDate.TabIndex = 19;
            this.regDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // typeName
            // 
            this.typeName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.typeName.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.typeName.FormattingEnabled = true;
            this.typeName.Location = new System.Drawing.Point(124, 129);
            this.typeName.Name = "typeName";
            this.typeName.Size = new System.Drawing.Size(250, 32);
            this.typeName.TabIndex = 20;
            this.typeName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(64, 463);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(92, 39);
            this.button10.TabIndex = 30;
            this.button10.Text = "修改";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(250, 463);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 39);
            this.button1.TabIndex = 31;
            this.button1.Text = "重置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(509, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(279, 404);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "操作窗口";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.newPassword);
            this.panel1.Controls.Add(this.newUsername);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Location = new System.Drawing.Point(6, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 222);
            this.panel1.TabIndex = 0;
            this.panel1.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(54, 177);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(178, 24);
            this.label14.TabIndex = 6;
            this.label14.Text = "换号将补办磁卡";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(111, 140);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 24);
            this.label13.TabIndex = 5;
            this.label13.Text = "注意";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(88, 89);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(105, 39);
            this.button4.TabIndex = 4;
            this.button4.Text = "确认";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // newPassword
            // 
            this.newPassword.Location = new System.Drawing.Point(102, 49);
            this.newPassword.Name = "newPassword";
            this.newPassword.Size = new System.Drawing.Size(153, 34);
            this.newPassword.TabIndex = 3;
            this.newPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NewPassword_KeyDown);
            // 
            // newUsername
            // 
            this.newUsername.Location = new System.Drawing.Point(102, 6);
            this.newUsername.Name = "newUsername";
            this.newUsername.Size = new System.Drawing.Size(153, 34);
            this.newUsername.TabIndex = 2;
            this.newUsername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NewPassword_KeyDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 24);
            this.label12.TabIndex = 1;
            this.label12.Text = "密码";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "用户名";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(380, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 39);
            this.button3.TabIndex = 34;
            this.button3.Text = "换号";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(60, 381);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 24);
            this.label15.TabIndex = 35;
            this.label15.Text = "系别";
            // 
            // dept
            // 
            this.dept.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dept.Location = new System.Drawing.Point(124, 378);
            this.dept.Name = "dept";
            this.dept.Size = new System.Drawing.Size(250, 34);
            this.dept.TabIndex = 36;
            this.dept.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dept_KeyDown);
            // 
            // sex
            // 
            this.sex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sex.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.sex.FormattingEnabled = true;
            this.sex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.sex.Location = new System.Drawing.Point(124, 256);
            this.sex.Name = "sex";
            this.sex.Size = new System.Drawing.Size(250, 32);
            this.sex.TabIndex = 37;
            // 
            // AdminUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 548);
            this.Controls.Add(this.sex);
            this.Controls.Add(this.dept);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.typeName);
            this.Controls.Add(this.regDate);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.age);
            this.Controls.Add(this.idCard);
            this.Controls.Add(this.name);
            this.Controls.Add(this.userCard);
            this.Controls.Add(this.password);
            this.Controls.Add(this.usernameT);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdminUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "用户信息";
            this.Load += new System.EventHandler(this.AdminUser_Load);
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox usernameT;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox userCard;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox idCard;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.TextBox regDate;
        private System.Windows.Forms.ComboBox typeName;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox newPassword;
        private System.Windows.Forms.TextBox newUsername;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox dept;
        private System.Windows.Forms.ComboBox sex;
    }
}